<html>
<head></head>
<body>
<form action="pex2b.php" method="post">
	Enter your message:
	<input type="text" name="txtMsg" size="30">
	<input type="submit" value="Send">
	</form></body>
</html>
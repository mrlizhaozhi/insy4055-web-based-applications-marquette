<html>
<head></head>
<body>
<form action="pex3d.php" method="post">
How many times you want to say "Hello World"?
<input type="text" name="txtNumber" size="10">
<input type="submit" value="Send">
</form>
</body>
</html>
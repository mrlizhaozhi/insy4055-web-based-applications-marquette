<?php
$input=$_POST["txtNumber"];
echo str_repeat("Hello World! ",(int)$input);
?>
<html>
<head></head>
<body>
<h1>Learning to write my first PHP code</h1><br/>

<?php
echo 'Hello World';
echo '<br/><h2>Hello World</h2><br/>';
echo '<em>Hello World</em>';
?>

<br/>
<h1>The is the end now</h1>
<br/>
</html>
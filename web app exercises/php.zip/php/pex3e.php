<html>
<head></head>
<body>
<form action="pex3f.php" method="post">
Number of Rows <input type="text" name="txtRow">
Number of Columns <input type="text" name="txtColumn">
<input type="submit" value="Send">
</form>
</body>
</html>
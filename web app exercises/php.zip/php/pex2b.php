<?php
$input=$_POST['txtMsg'];
echo "You said: $input";
echo "You said: ".$input;
?>
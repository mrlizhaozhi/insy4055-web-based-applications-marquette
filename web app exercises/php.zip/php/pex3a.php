<html>
<head></head>
<body>
<form action="pex3b.php" method="post">
	Enter your First Name:
	<input type="text" name="txtFirstName" size="20">
	Enter your Last Name:
	<input type="text" name="txtLastName" size="20">
	<input type="Submit" value="Send">
</form>
</body>
</html>